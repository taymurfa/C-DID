# Handoff: Speaker Signal Frontend/Dashboard

## Overview
Speaker Signal surfaces high-value conference speakers as sales leads: it ingests conference agendas, scores speakers as buying signals, and drives an outreach sequence and funnel through to booked meetings. This package hands off a working prototype and fixture data for a real **Next.js + TypeScript + Tailwind + shadcn/ui** build.

## About the Design Files
The bundled file (`reference/Speaker Signal.dc.html`) is a **design reference built in HTML** — a click-through prototype showing intended layout, states, and flow. It is not production code to copy directly. The task is to **recreate this design in Next.js/TypeScript/Tailwind/shadcn/ui**, per the architecture below — not to ship the HTML.

## Fidelity
**High-fidelity.** Colors, spacing, type scale, and copy in the prototype are final. Build pixel-close to it using Tailwind utilities and shadcn/ui primitives (Card, Table, Badge, Button, Tabs, Progress) rather than recreating raw CSS.

## Target Architecture (per original spec)
- Next.js (App Router) + TypeScript + Tailwind + shadcn/ui + Recharts, served on port 3000.
- Three backend services, never called directly from UI components:
  - Ingestion — `http://localhost:8001` (env: `INGESTION_API_URL`)
  - Intelligence — `http://localhost:8002` (env: `INTELLIGENCE_API_URL`)
  - GTM — `http://localhost:8003` (env: `GTM_API_URL`)
- Service clients: `lib/api/ingestion.ts`, `lib/api/intelligence.ts`, `lib/api/gtm.ts`. Each exports typed functions (e.g. `ingest(url)`, `analyze(raw)`, `createSequence(conference, lead)`) that internally branch on demo mode — components only ever call these functions, never `fetch()` a service URL directly.
- Demo mode: `NEXT_PUBLIC_DEMO_MODE=true`. When set, the API clients read from the bundled fixture JSON (`fixtures/*.json`, included in this package) instead of calling the services. This lets the frontend be fully built and demoed before backend services exist.
- Orchestration (lives in the frontend, not a 4th service):
  ```ts
  async function analyzeConference(url: string) {
    const raw = await ingestion.ingest(url);
    const analysis = await intelligence.analyze(raw);
    return analysis;
  }
  // separate call, only when the user starts outreach:
  await gtm.createSequence(conference, lead);
  ```
- Error handling: each service call is wrapped so a single service failure shows an inline error/retry state in just the affected panel — it must never crash the rest of the dashboard. When `NEXT_PUBLIC_DEMO_MODE` is available, the error state offers a "Load demo data" fallback action.
- `npm run build` and `npm run lint` must pass clean before calling this done.

## Fixture Contracts
Included in `fixtures/`, matching the shapes below (see files for full data — 4 conferences, 25 speakers: 8 A-tier, 8 B-tier, remainder C/D):

- **`ingestion.json`** — raw ingestion output: `conferences[]` (id, name, location, date, vertical, sourceUrl) and `sessions[]` (speakerName, title, company, conferenceId, sessionTitle, sourceUrl). This is what `ingestion.ingest(url)` returns in demo mode.
- **`analyzed-leads.json`** — output of `intelligence.analyze(raw)`: one entry per speaker with `id, conferenceId, name, title, company, session, score{roleFit /25, companyFit /20, sessionRelevance /25, seniority /15, buyingInfluence /10, confidence /5}, total, tier (A/B/C/D), whyNow, positiveSignals[], negativeSignals[], evidence[] ({text, url}), hasSequence`.
- **`sequences.json`** — one entry per lead with an active sequence: `leadId, conferenceId, steps[]` where each step is `{key, label, offset (days from conference date), scheduledDate, status (sent/scheduled), draft}`. Steps: Initial (T-14) → Follow-up (T-7) → Meet at event (T-2) → Event Meet (T0) → Post-event (T+2).
- **`funnel.json`** — `stages[]`: `{key, label, count}` in order Identified → Contacted → Replied → Meeting scheduled → Met at event → Follow-up sent → Conversation booked. Derive conversion % and dropoff % per stage as `count / previous.count` at render time; don't bake percentages into the fixture.

Scoring notes: `total = sum of score fields` (max 100); tier thresholds used in the prototype are A ≥ 90, B ≥ 75, C ≥ 60, D < 60 — adjust if Intelligence service defines its own thresholds later.

## Navigation
Left sidebar, fixed width (~232px), dark background, sections in this order: **Overview, Conferences, Speakers, Sequences, Funnel, System**. Active item highlighted with a filled rounded background. A small "Demo Mode" indicator pill sits pinned at the sidebar bottom whenever `NEXT_PUBLIC_DEMO_MODE=true`.

## Screens

### 1. Overview
- **Purpose**: Landing dashboard; entry point to start a new conference analysis and see top leads at a glance.
- **Layout**: URL input + "Analyze Conference" button in a bordered panel at top. Below it, a 6-column KPI grid (Upcoming conferences, Qualified speakers, A-tier leads, Active sequences, Replies, Meetings booked). Below that, a vertical list of "Top Signals" cards.
- **Analyze flow**: clicking "Analyze Conference" opens a modal overlay showing pipeline stages — **Discovering → Scraping → Extracting → Resolving → Scoring** — each with a status dot (pending = dim gray, active = pulsing amber, done = green). Advance one stage roughly every 700–800ms; on completion, close the modal and route to the resulting Conference view. This maps to the real `analyzeConference(url)` call — stages are cosmetic while awaiting the actual async response in production, or can reflect real sub-step progress if the Intelligence service streams status.
- **Top Signal card fields** (per spec, one row per Tier-A lead): Name, Title, Company, Conference name, Days until conference, Session topic, Overall score /100, Tier badge, "WHY NOW" text, "NEXT ACTION" text. Score and days-until should dominate visually (large monospace numerals).

### 2. Conferences
- Grid of conference cards: vertical/category label, name, location + date, days-until countdown (large, amber), and a mini stat row (speaker count, A-lead count, active sequences). Clicking a card opens Conference Detail.

### 3. Conference Detail
- Header: conference name, location, date, big countdown number.
- Stat row: speakers, A leads, B leads, active sequences, meetings.
- Table (sorted by score descending): speaker, title, company, session, score, tier badge, why-they-matter, sequence status. Row click → Lead Detail.

### 4. Speakers (directory)
- All 25 speakers across conferences, same table shape as Conference Detail plus a Conference column. Tier filter chips (All/A/B/C/D) above the table.

### 5. Lead Detail
- Two-column layout.
  - Left: identity card (name, title, company, tier badge) + conference/session block; positive signals list (green +); negative signals list (red −); evidence list, each item showing its source **URL as a link** (required — every evidence item must expose its source).
  - Right: score breakdown card — six rows (Role Fit, Company Fit, Session Relevance, Seniority, Buying Influence, Confidence) each as a labeled progress bar with `value/max`, then a Total `/100` line; a "Why now" + "Next action" card with a CTA button ("Start sequence" or "View sequence" depending on state) that calls `gtm.createSequence(conference, lead)` the first time.

### 6. Sequences (list)
- Table: lead, conference, next scheduled step + date, countdown to conference, status (In progress/Complete). Row click → Sequence Detail.
- If the GTM service is down, show a dismissible-but-persistent banner above the table with the error and a Retry button; sequence data still renders from cache/fixtures underneath.

### 7. Sequence Detail
- Vertical timeline, one row per step (dot + connecting line), each showing: label, scheduled date, status badge (Sent/Scheduled), and the drafted outreach copy in a monospace text block. Order: T-14 Initial, T-7 Follow-up, T-2 Meet at event, Event Meet, T+2 Post-event.

### 8. Funnel
- One row per stage (Identified → Contacted → Replied → Meeting scheduled → Met at event → Follow-up sent → Conversation booked): label, count, conversion % (vs. previous stage), dropoff %, and a horizontal bar sized relative to the top-of-funnel count. The stage with the largest dropoff gets a "BIGGEST LEAK" badge and a highlighted border.

### 9. System
- Three cards, one per service (Ingestion, Intelligence, GTM): service name, green/red status dot + label, the service's base URL, one-line description of what it does, latency (ms) when healthy, an inline error message when down, and a Retry button on a down service.

## Interactions & Behavior
- All row/card clicks navigate via Next.js routing (e.g. `/conferences/[id]`, `/leads/[id]`, `/sequences/[id]`) rather than client-only state, so views are linkable.
- Retry buttons re-invoke the relevant API client function; while retrying, disable the button and show "Retrying…".
- No destructive actions; this is a read/monitor + sequence-kickoff tool.

## Design Tokens
- **Background**: near-black neutral, `oklch(0.145 0 0)`; panel background `oklch(0.17 0 0)`; borders `oklch(0.26 0 0)`.
- **Text**: primary `oklch(0.94 0 0)`, secondary `oklch(0.62–0.68 0 0)`, tertiary `oklch(0.5–0.55 0 0)`.
- **Tier colors**: A green `oklch(0.85 0.17 155)` on `oklch(0.27 0.06 155)`; B amber `oklch(0.86 0.15 90)` on `oklch(0.28 0.06 90)`; C blue `oklch(0.82 0.12 235)` on `oklch(0.26 0.05 235)`; D gray `oklch(0.72 0.02 250)` on `oklch(0.22 0.01 250)`.
- **Status**: healthy/sent green `oklch(0.75–0.78 0.17 155)`; warning/pending amber `oklch(0.8 0.13 90)`; error/down red `oklch(0.65–0.72 0.18 25)`; accent blue (links, progress bars) `oklch(0.72 0.14 235)`.
- **Typography**: UI text — Geist (fallback: system-ui sans). Numerals/scores/code/URLs — Geist Mono (fallback: ui-monospace). Score numerals and countdowns render large (22–30px) and bold/semibold; body text 12–14px.
- **Radius**: cards/panels 10–12px; chips/badges fully rounded (pill); inputs/buttons 7–8px.
- **Density**: tight padding (11–20px), small gaps (8–14px) — this is a high-density data product, not a marketing page.

## Assets
No images or icons in the prototype — purely typographic/data-driven. If icons are wanted in the real build, use an existing icon set already in the codebase (e.g. lucide-react, which ships with shadcn/ui) rather than introducing a new one.

## Files
- `reference/Speaker Signal.dc.html` — the interactive prototype (open in any browser).
- `fixtures/ingestion.json`, `fixtures/analyzed-leads.json`, `fixtures/sequences.json`, `fixtures/funnel.json` — demo fixture data, ready to drop into the Next.js project's `fixtures/` directory as-is.
